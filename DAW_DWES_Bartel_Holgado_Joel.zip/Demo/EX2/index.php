<?php
$shopping_cart = 151;
$tipo = array('cables','perifericos');
$tipo[0]="cables";
$shipping_price = 0;
if($shopping_cart<20){
    if($tipo[1]=="cables"){
        echo " Los cables no se pueden enviar";
    }else{
        $shipping_price=4.99;
        echo " Los perifericos tienen los gastos de envío son,$shipping_price €";

    }

}elseif($shopping_cart>=20&&$shopping_cart<=50){
    $shipping_price=4.99;
    echo "El envio esta entre 20 y 50 € por tanto Los gastos de envio son,$shipping_price €";
}else{}

if($shopping_cart>=50&&$shopping_cart<=150){
    echo " El pedido es superior a 50€ tienes los portes de envio gratis";
}elseif($shopping_cart>150){
    echo "La compra super los 150€ para su proxima compra tienes un codigo de descuento llamado:GIMBERNAT_20_%";
}else{}

