### Explicacion EX2

He creado 3 variables:

$shipping_price:indica el valor de gastos de envios.

$tipo:indica el tipo del array, cables o perifericos

$shopping_cart:indica el precio que va a gastar en la compra.

Primero he pensado en hacer if else para que se cumpla la primera condicion, despues para que el valor del precio este entre 20-50 he utilizado un AND(&&) y luego he utilizado tambien lo mismo para que el valor este entre 50-150 si se pasa de 150 ya salta a otra condicion.